# Rbx Market

Marketplace to sell Roblox accounts.

- Contact via Discord: `RbxSeller689`
- PayPal: `cleencuevas@gmail.com`

## How to Run
```bash
npm install
npm run dev
```